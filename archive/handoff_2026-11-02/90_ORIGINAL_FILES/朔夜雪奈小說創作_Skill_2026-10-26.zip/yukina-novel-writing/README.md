# Skill 使用說明

這份 ZIP 符合 Agent Skills 的基本 `SKILL.md` + `references/` 目錄形式。

- ChatGPT 支援 Skills 的符合資格工作區：外掛程式 → 技能 → 建立 → 從電腦上傳 ZIP，或透過對話建立。是否可使用取決於方案與工作區設定。
- ChatGPT Plus 個人方案目前不是官方列出的 Skills 建立／安裝適用方案，因此可以先保存 ZIP，但不能假設已安裝。
- Plus 可以建立 ChatGPT 專案（Project），把「精簡啟動指令」貼入該專案的 Instructions，並將方法學、角色正典與索引作為專案檔案／來源，即可達到相近的持續使用效果；專案設定仍需使用者在介面操作。
- 若 Skill 已可安裝，安裝後的 Skill 只負責觸發創作流程；正典以外部原始檔為準，並不是把設定寫死。
