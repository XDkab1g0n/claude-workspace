# ChatGPT → Claude 移交包（初始版）

**建立日期：2026-11-01（Asia/Taipei）**  
**性質：可立即使用的交接摘要；不等於全量資料匯出。**

這份交接包根據目前可見的 ChatGPT 記憶摘要、使用者在本對話提供的個人指令與專案資訊製作。其目的，是幫助 Claude 理解使用者的偏好、常用設備、長期專案，以及尚待重新部署的排程。沒有在本次工作中逐一讀取全部原始聊天、小說正典、考題與排程完整提示詞，因此相關資料應以原始檔為準，不可把摘要冒充完整原文。

## 檔案導覽

- `01_GLOBAL_INSTRUCTIONS.md`：建議放在 Claude 全域偏好、Cowork 全域指令或各專案指令的核心規範。
- `02_USER_CONTEXT.md`：適合 Claude 的 Memory Import 或按主題補入 Claude 記憶（匯入前先審閱）。
- `03_PROJECT_HANDOFF.md`：建議拆分到各自的 Claude Project Knowledge，尤其是「雪奈」與「醫學國考」。
- `04_SCHEDULED_TASKS.md`：目前已知的 ChatGPT 排程清單及重新建立的工作指示。
- `05_ONBOARDING_AND_QA.md`：第一輪 Claude 導入提示與驗收測試。

## 建議順序

1. 在 ChatGPT 設定 → 資料控制 → 匯出資料，下載原始對話 ZIP，離線保存並核對完整性。
2. 在 ChatGPT 設定 → 個人化 → Memory summary → Manage，檢查當前記憶摘要；將細節補進 `02_USER_CONTEXT.md`。
3. 於 Claude 網頁版 Settings → Your Claude → Start import 匯入記憶。
4. 將 `01_GLOBAL_INSTRUCTIONS.md` 改寫／貼入 Claude 全域偏好，避免只依賴記憶匯入。
5. 在 Claude Projects 建立個別工作區，上傳原始資料、專案規則、最新成果、待辦與來源索引。
6. 在 Claude Scheduled／Cowork 重建排程：必須取回每一項「完整」提示詞、時區、執行頻率、來源要求、品質控制及差分規則，不能只根據此摘要重建。
7. 使用 `05_ONBOARDING_AND_QA.md` 驗收；核對 Claude 真正記住了什麼、能否找出正典、如何援引來源。

## 來源資料應額外取得

- 從 ChatGPT 官方匯出的聊天紀錄；重要附件、產出檔及 Library 檔案應另外確認是否已保存，不可假定匯出 ZIP 包含全部檔案。
- 「朔夜雪奈／ZERO NIGHT」唯一正典 v17.7、最新版寫作方法學、README 取用索引，以及真正存在的設定與創作稿。
- 醫師國考正式成績、135 題錯題詳解、分類統計、題庫 CSV 及任何作答原始資料。
- 工作新聞早午晚報、體育雷達 v3、遊戲與消費電子雷達三個任務的**完整原始排程 Prompt**（這份摘要並未包含完整版本）。
- 對話中產出的報告、檔案、程式碼、索引和研究來源；需要長期使用的部分應存為可讀文件，而不是只留在原始聊天 ZIP。

## 隱私與正確性

匯入跨服務前，請先檢視包含健康、個人位置、親友、聯絡方式與第三人資訊的項目。本包刻意未納入細緻的健康與身分識別資料。使用者可以再自行選擇哪些內容要交給 Claude。所有資訊都是「截至交接日的狀態」，未經二次驗證的裝置規格、交易價格和工作進度不應視為即時事實。

## 官方參考

- Claude 記憶匯入：https://support.claude.com/zh-TW/articles/12123587-從-claude-匯入和匯出您的記憶
- Claude Projects：https://support.claude.com/en/articles/9519177-how-can-i-create-and-manage-projects
- Claude Scheduled：https://support.claude.com/en/articles/13854387-schedule-recurring-tasks-in-claude-cowork
- ChatGPT 資料匯出：https://help.openai.com/en/articles/7260999-exporting-your-chatgpt-history-and-data
