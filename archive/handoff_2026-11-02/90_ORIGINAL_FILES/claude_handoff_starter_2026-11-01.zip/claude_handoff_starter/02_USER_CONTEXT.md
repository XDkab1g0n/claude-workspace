# 使用者長期脈絡與偏好（供審閱後匯入 Claude Memory）

> 2026-11-01 交接摘要。此文件屬個人化資訊，匯入前由使用者確認與刪減。

## 核心背景

- 使用者長期使用繁體中文，是接受過臨床訓練的住院醫師，熟悉醫學證據與專科術語，持續處理醫師國考相關資料。
- 常討論台灣與國際時事、半導體／AI 產業、科技股、汽車、消費電子、遊戲、音樂與耳機、攝影、高爾夫與小說創作。
- 對 AI 的核心期待是可靠查證、深度分析、積極完成任務和精確驗收，特別討厭重複犯錯、過度防衛性語句和偷懶式縮減範圍。
- 偏好長篇 Thinking 推理與可互動的豐富介面；如沒有等效 UI，至少維持高可讀性與可操作性。

## 電子設備與網路（可能隨時間變動）

- 主要桌機：Intel i5-13500、RTX 4070 EAGLE OC、Z690 AORUS ULTRA、DDR5 5600 32GB；主要螢幕 Gigabyte GO27Q24A，副螢幕 M27Q。
- 筆電：ROG Zephyrus G14 2024 RTX 4060。平板：iPad Pro 13 M4。
- 手機：2026-09-29 入手 Samsung Galaxy Z Fold 8（白色 12/256）；亦有 Xiaomi 17。看重摺疊內螢幕的 4:3 比例及雙 App 使用。
- **家用核心路由器是 TP-Link Archer BE550，絕對不是 ASUS BE550。** AX73 是 Mesh 子機；此品牌更正曾被反覆強調。

## 音訊與音樂

- 桌面耳機鏈：Topping DX5 II + A70 Pro；主要耳罩 HIFIMAN Arya Stealth；其他 HD 490 Pro、DT990 Pro 250Ω。
- IEM：LETSHUOER S15（主力）、S12 Ultra、SeeAudio 輝夜2、Sony IER-M500；TWS Sony WF-1000XM5。
- 持續收集日本流行／音遊／Hardcore 等作品的作曲者、製作人與評價；關注 HARDCORE TANO*C 等音樂圈。
- 主歌單約千首；「加進歌單」是強烈正向回饋，但未加入不代表不喜歡。
- 有約十年鋼琴學習背景。

## 攝影、運動、交通

- 相機 Canon EOS R7；RF-S 10-18、18-150，RF 28/2.8，Sigma RF 18-50/2.8、56/1.4。
- 高爾夫練習約十年，常態球場約 90 桿上下；主力 Driver Titleist TSi2，Mizuno forged 鐵桿。
- SYM FNX（2018 年初代六期）為通勤用機車；家用車包括 2017 Corolla Altis 與 Toyota Previa，長期比較換車／Hybrid／停車升降梯重量限制。

## 內容偏好

- 遊戲常玩 Apex、Yu-Gi-Oh! Master Duel、絕區零、異環、NBA 2K、eBaseball、LoL、Splatoon；Persona 5 Royal 喜歡雙葉。
- 關注 NBA 雷霆、MLB 台灣旅外、F1 與台灣體育，也關注電腦硬體、磁軸鍵盤及外設。
- 對音樂、消費科技、股市與遊戲評價，喜歡客觀衡量與多來源交叉比對，並要求具體差異和資料。
- 長期食譜：Carbonara 單人配方乾麵 100g、Parmigiano 25g、全蛋 1+蛋黃 1、培根 100g、低鹽麵水 0.4%；此為個人既定版，勿任意替換。

## AI 使用偏好與已知問題

- 高頻使用長對話、深度推理、資料比對與任務排程；特別重視較佳 Thinking 推理品質及 Intelligent UI 的互動性。
- 曾反覆遇到排程輸出丟失、模型選擇未被遵守、跨模式上下文斷裂；對應修正是把任務指令、品質基準與來源資料顯式文件化。
- 不要將短期型號與價格資訊視為永續事實，需依任務再核實。
