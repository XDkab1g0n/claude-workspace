# Matt Pocock Skills 安裝包

官方儲存庫：`mattpocock/skills`

這個壓縮檔是「官方安裝器啟動包」，執行時會由官方來源抓取最新版 skills；它不是離線封存副本。

## Windows

1. 安裝 Node.js LTS。
2. 解壓縮此檔案。
3. 在資料夾內開啟 PowerShell。
4. 執行：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install.ps1
```

## macOS / Linux

```bash
chmod +x install.sh
./install.sh
```

## 安裝時注意

- 選擇 skills 時，務必包含 `setup-matt-pocock-skills`。
- 安裝完成後，在每個專案內執行一次 `/setup-matt-pocock-skills`。
- 官方說明指出：Claude Code plugin 與 `skills.sh`／`npx skills` 路徑二選一，兩者都裝會造成重複 skills。

## Claude Code 的另一種官方安裝法

```bash
claude plugins install mattpocock-skills
```

若採用這種方式，就不要再執行本包內的 `npx skills` 安裝器。
