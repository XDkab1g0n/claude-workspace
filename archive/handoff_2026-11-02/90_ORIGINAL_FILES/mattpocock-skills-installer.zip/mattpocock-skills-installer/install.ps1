$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
    Write-Error '找不到 npx。請先安裝 Node.js LTS，重新開啟終端機後再執行本腳本。'
}

Write-Host '正在啟動 mattpocock/skills 官方安裝器...'
Write-Host '選擇 skills 時，請務必勾選 setup-matt-pocock-skills。'
& npx --yes skills@latest add mattpocock/skills
if ($LASTEXITCODE -ne 0) {
    throw "skills 安裝器執行失敗，結束代碼：$LASTEXITCODE"
}

Write-Host ''
Write-Host '安裝完成。請在每個專案內執行一次：/setup-matt-pocock-skills'
