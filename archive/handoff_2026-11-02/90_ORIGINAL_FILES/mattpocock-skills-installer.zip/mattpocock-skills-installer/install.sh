#!/usr/bin/env bash
set -euo pipefail

if ! command -v npx >/dev/null 2>&1; then
  echo '找不到 npx。請先安裝 Node.js LTS，重新開啟終端機後再執行本腳本。' >&2
  exit 1
fi

echo '正在啟動 mattpocock/skills 官方安裝器...'
echo '選擇 skills 時，請務必勾選 setup-matt-pocock-skills。'
npx --yes skills@latest add mattpocock/skills

echo
echo '安裝完成。請在每個專案內執行一次：/setup-matt-pocock-skills'
