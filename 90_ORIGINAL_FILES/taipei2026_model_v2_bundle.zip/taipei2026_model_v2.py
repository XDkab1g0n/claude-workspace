"""2026台北市長：可重算條件得票情境模型（不產出勝率）。
每個參數只代表使用者設定的反事實假設，除歷史票數以外未做因果校準。
"""
from math import exp,log
from datetime import date
import csv
from pathlib import Path

SOURCE_DATE = date(2026,10,9)
POLL_INPUTS = {
 'TVBS 10月': dict(chiang=49.,shen=41.,undecided=11.,minor=0.,excluded=0.,kind='兩人對比／沒有其他參選者的分母'),
 '信民 9月':dict(chiang=41.7,shen=40.5,undecided=10.6,minor=2.1,excluded=5.2,kind='六人題目／不投票及廢票自有效票排除'),
}
HISTORY = {
 '2022 市長兩人':(575590.,434558.),
 '2024 總統藍綠':(587258.,587899.),
}
CONTEXT = {
 'council_log_ratio': log(30./21.),
 'recall_log_ratio': log(428596./330340.),
 'approval_net_reference': 52.-35.,
 'self_report_huang_share_pct':15.,
 'self_report_huang_chiang_pct':39.,
 'self_report_huang_shen_pct':53.,
}
DEFAULTS=dict(undecided_to_shen=50.,historical_blend=0.,history_base='2024 總統藍綠',
              council_log_weight=0.,recall_log_weight=0.,approval_delta_net=0.,approval_log_weight=0.,
              cohort_shift=0.,cohort_share=15.,turnout_ratio_c=1.,turnout_ratio_s=1.,minor_ratio=1.)
BOUNDS=dict(undecided_to_shen=(0,100),historical_blend=(0,.35),
            council_log_weight=(-.25,.25),recall_log_weight=(-.25,.25),
            approval_delta_net=(-20,20),approval_log_weight=(-.2,.2),
            cohort_shift=(-20,20),cohort_share=(0,25),
            turnout_ratio_c=(.8,1.2),turnout_ratio_s=(.8,1.2),minor_ratio=(.8,1.2))
def logistic(z):
    if z>=0: return 1/(1+exp(-z))
    u=exp(z);return u/(1+u)
def logit(p):
    if not 0<p<1:raise ValueError('logit only accepts a probability strictly between zero and one')
    return log(p/(1-p))
def run_model(poll='TVBS 10月',**updates):
    if poll not in POLL_INPUTS:raise KeyError('unknown poll baseline')
    a=DEFAULTS.copy();a.update(updates)
    for k,(lo,hi) in BOUNDS.items():
        if not lo<=a[k]<=hi:raise ValueError(f'{k} outside [{lo},{hi}]')
    if a['history_base'] not in HISTORY:raise ValueError('unknown historical comparison')
    b=POLL_INPUTS[poll]
    raw_c=b['chiang']+b['undecided']*(1-a['undecided_to_shen']/100)
    raw_s=b['shen']+b['undecided']*a['undecided_to_shen']/100
    # 只對「自述2022投黃者」在當期問卷之後的 *變化* 建模，不把舊票絕對分布重算一次
    cohort_points=(a['cohort_share']/100.)*a['cohort_shift']
    raw_c+=cohort_points;raw_s-=cohort_points
    if min(raw_c,raw_s)<=0:raise ValueError('cohort input exceeded ballot mass')
    pair_total=raw_c+raw_s
    p0=raw_c/pair_total
    h_c,h_s=HISTORY[a['history_base']]
    h_p=h_c/(h_c+h_s)
    # 資料本身可重算的 log-odds 差；融合係數本身為可調敏感度假設，非估計出的因果效應。
    history_term=a['historical_blend']*(logit(h_p)-logit(p0))
    organization_term=a['council_log_weight']*CONTEXT['council_log_ratio']
    recall_term=a['recall_log_weight']*CONTEXT['recall_log_ratio']
    approval_term=a['approval_log_weight']*(a['approval_delta_net']/10.)
    terms=dict(history=history_term,council=organization_term,recall=recall_term,approval_change=approval_term)
    logits=logit(p0)+sum(terms.values())
    cc=pair_total*logistic(logits)*a['turnout_ratio_c']
    ss=pair_total*(1-logistic(logits))*a['turnout_ratio_s']
    mm=b['minor']*a['minor_ratio']
    d=cc+ss+mm
    return dict(poll=poll,chiang_pct=100*cc/d,shen_pct=100*ss/d,
                other_pct=100*mm/d,source_pair_pct=100*p0,
                base_major_pair_pct=100*b['chiang']/(b['chiang']+b['shen']),
                raw_mass=dict(chiang=raw_c,shen=raw_s,minor=b['minor'],excluded=b['excluded']),
                context=dict(CONTEXT),terms_logodds=terms,
                total_logodds_shift=sum(terms.values()),
                parameters=a,denominator=d,
                note='conditional counterfactual, not an observed result or probabilistic forecast')
