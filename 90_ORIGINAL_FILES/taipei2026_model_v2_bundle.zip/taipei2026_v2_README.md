# 台北市長 2026：得票情境模型 v2

截止日期：2026-10-09。模型只計算**條件得票率與敏感度**，不產出候選人的勝選機率。

## 檔案
- `taipei2026_election_model_v2.ipynb`：已執行、內嵌資料與圖表的 Notebook。
- `taipei2026_model_dashboard_v2.html`：單檔離線互動介面；可匯出設定 JSON。
- `taipei2026_model_v2.py`：純 Python 模型函數，無第三方依賴。
- `taipei2026_factors_v2.csv`：係數字典（每個係數的定義、範圍、實際數據、識別狀態）。
- `taipei2026_sensitivity_v2.csv`：兩個民調基準各12種情境算術結果。
- `taipei2026_polls.csv`、`taipei2026_nonpoll.csv`、`taipei2025_recall.csv`：原來的輸入資料，並在 Notebook 原文嵌入來源。

## 模型方程與重要界限

兩人支持票先依不同調查的未表態比例分流；自述黃珊珊舊選民的**當期後續變動**按群體當期占比移轉。令 C、S 為調整後的票量，r=C/(C+S)，歷史兩人比率為 h。採 log-odds 模型：

```
logit(r_new) = logit(r)
  + historical_blend * (logit(h) - logit(r))
  + council_log_weight * ln(30/21)
  + recall_log_weight * ln(428596/330340)
  + approval_log_weight * (approval_delta_net / 10)
```

再乘以 C / S 各自的相對投票參與因子；六人題目保留其他四人。所有值重新正規化為有效票100%。

**係數不是估計得出的因果效果**。2022議席、2025五區罷免、2026施政滿意本身不識別2026候選人投票率的變化，非零係數只是可重算的「如果」假設。TVBS與信民問法不同，不可把兩人題視為完整六人選舉。當期交叉表已包含在當期支持度，僅允許增量分析避免雙重計數。

## 核對來源
- TVBS 2026/10: https://news.tvbs.com.tw/politics/4033527
- TVBS 評價與交叉表: https://news.tvbs.com.tw/politics/4033530
- 信民2026/9: https://news.tvbs.com.tw/politics/4025675
- 2022台北市長: https://www.cna.com.tw/news/aipl/202211260299.aspx
- 2025五席罷免: https://www.cna.com.tw/news/aipl/202507260215.aspx
- 其他六份民調／歷史資料的原始URL，見 Notebook `POLLS` / `CONTEXT`。
