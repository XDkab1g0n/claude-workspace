# 朔夜雪奈｜蒸餾 Coverage Map v1

## 判讀方式

- **Kernel 高保真**：核心內容直接保留或極小幅合併，可作 always-on canon。
- **Kernel 蒸餾 + Annex 原文**：Kernel 留生成所需不變量，精確細節以 Annex 保存。
- **Annex 原文**：從 v17.7a 母本直接抽取，不做設定改寫。

| 母本章節 | 新位置 | 處理 |
|---|---|---|
| 0 設定定位 | Kernel 1、13、14 | Kernel 高保真 |
| 1 不可變核心 | Kernel 1 | Kernel 高保真 |
| 2 外觀、身體與動態 | Kernel 2；Annex A 2.4–2.6；Annex B 2.3 | Kernel 蒸餾 + Annex 原文 |
| 3 人格 | Kernel 3；Annex C 3.5 | Kernel 高保真／關係細節原文 |
| 4 對話與即時反應 | Kernel 4；Annex C | Kernel 蒸餾 + Annex 原文 |
| 5 三個生活／作戰面向 | Kernel 5.1–5.2；Annex C | Kernel 蒸餾 + Annex 原文 |
| 6 銀色幽靈 | Kernel 5.3 | Kernel 高保真 |
| 7 零夜 | Kernel 5.4 | Kernel 高保真 |
| 8 戰鬥能力 | Kernel 6；Annex A | Kernel 蒸餾 + Annex 原文 |
| 9 戰力尺度 | Kernel 6.4；Annex A | Kernel 蒸餾 + Annex 原文 |
| 10 戰鬥語彙 | Kernel 6.2；Annex A | Kernel 蒸餾 + Annex 原文 |
| 11 昇月 | Annex A | Annex 原文 |
| 12 彗星 | Annex A | Annex 原文 |
| 13 銀色幽靈視覺與裝備 | Kernel 7；Annex B | Kernel 最小索引 + Annex 原文 |
| 14 零夜視覺與裝備 | Kernel 7；Annex B | Kernel 最小索引 + Annex 原文 |
| 15 樞紐與導航員 | Kernel 8；Annex B | Kernel 高保真 + Annex 原文 |
| 16 傷勢、資源與風險 | Kernel 9；Annex A | Kernel 蒸餾 + Annex 原文 |
| 17 過去與現在 | Kernel 10；Annex C | Kernel 蒸餾 + Annex 原文 |
| 18 重要關係 | Kernel 11–12；Annex C | Kernel 索引 + Annex 原文 |
| 19 故事生成原理 | Kernel 13 | Kernel 高保真，包含 v17.7a 新增危險美感句 |
| 20 一句話版本 | Kernel 15 | 原文保留 |

## 已刻意不蒸餾掉的高風險變數

- 18歲、高三、149cm／38kg、外觀約15～16歲。
- 自然人、非義體、非植入。
- 自主權與完整拒絕權。
- 學生／私人／銀色幽靈／零夜不是人格切換。
- 銀色幽靈＝自由／表演／即興；零夜＝公共責任／收束／團隊，但仍是同一雪奈。
- 腿是近身第一主武器；嬌小身體與重型破壞力反差。
- 強但是真實血肉；傷勢與資源會壓縮選項。
- 過去是因果，不是固定反應模板。
- 關係具有對象特異性。
- 導航員是獨立人格搭檔，不是服從工具。
- 暴力與身體美感可以同時存在；力學只做底層裁判。

## 母本仍保留

本蒸餾包不取代母本。若 Kernel 與 Annex 都無法裁決，回查：
`雪奈_現行主設定_v17.7a.md`
